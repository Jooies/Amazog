<?php
class m_acl extends spModel{
    var $pk = "id";
    var $table = "acl";
}