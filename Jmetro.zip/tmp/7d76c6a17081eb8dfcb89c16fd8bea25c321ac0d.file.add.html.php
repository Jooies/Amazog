<?php /* Smarty version Smarty-3.0.8, created on 2013-04-29 07:35:41
         compiled from "E:\wamp\www\Jmetro/template\page/add.html" */ ?>
<?php /*%%SmartyHeaderCode:9549517db24d638b29-11522046%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7d76c6a17081eb8dfcb89c16fd8bea25c321ac0d' => 
    array (
      0 => 'E:\\wamp\\www\\Jmetro/template\\page/add.html',
      1 => 1367191942,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9549517db24d638b29-11522046',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link href="public/css/admin.css" rel="stylesheet" media="screen">
<style>
.box {text-align: left;width: 725px;}
.input-block-level {width: 630px !important;}
em {color: red;}
</style>
</head>
<div class="box">
<!--form-->
<form action="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'page','a'=>'add'),$_smarty_tpl);?>
" method="post">
<!--title-->
<div class="row">
<label class="label">页面标题：</label><input type="text" name="title" class="input-block-level" placeholder="请输入页面标题...">
</div><br>
<center><textarea name="content" rows="10" cols="800"></textarea></center><br>
<div class="row">
<label class="label"><em>*</em> </label>在页面中，可以添加一些特殊的标签来显示一些特殊的内容。详细标签内容请翻阅文档！
</div><br>
<input type="submit" name="c_submit" value="添加页面" class="submit">  
</form>
</div>
</html>