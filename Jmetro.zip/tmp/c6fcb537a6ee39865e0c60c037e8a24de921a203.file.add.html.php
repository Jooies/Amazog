<?php /* Smarty version Smarty-3.0.8, created on 2013-04-29 07:37:12
         compiled from "E:\wamp\www\Jmetro/template\category/add.html" */ ?>
<?php /*%%SmartyHeaderCode:13646517db2a8e29a03-96534258%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c6fcb537a6ee39865e0c60c037e8a24de921a203' => 
    array (
      0 => 'E:\\wamp\\www\\Jmetro/template\\category/add.html',
      1 => 1365053392,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13646517db2a8e29a03-96534258',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link href="public/css/admin.css" rel="stylesheet" media="screen">
<style>
input[type="text"]{border-radius:0px;height:22px;width:200px;}
.form-list .label{width:70px;font-size: 13px}
</style>
</head>
<div class="box">
<div class="form-list">
<!--form-->
<form action="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'category','a'=>'add'),$_smarty_tpl);?>
" method="post">
<!--title-->
<div class="row">
<label class="label">分类名称:</label>
<input type="text" name="name" placeholder="请输入分类名..."><br><br>
<input type="submit" name="c_submit" value="添加" class="btn">
</div>
</form>
</div>
</div>
</html>
