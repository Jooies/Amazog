<?php /* Smarty version Smarty-3.0.8, created on 2013-04-21 12:22:19
         compiled from "E:\wamp\www\Jmetro/template\skin/black/main/register.html" */ ?>
<?php /*%%SmartyHeaderCode:85975173697be12029-45186631%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f8a0eba0cc99959dbb1782fdfa489cf3dcdbe613' => 
    array (
      0 => 'E:\\wamp\\www\\Jmetro/template\\skin/black/main/register.html',
      1 => 1366518139,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '85975173697be12029-45186631',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>注册</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link href="public/css/style.css" rel="stylesheet" media="screen">
</head>
<body style="background:#f1f1f1;">
<div class="container">
<center><div class="col3"><br><br><br><br><h1>注册</h1></div>
<div class="col5"  style="float:center;"><br><br><br><br>
<form action="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'register'),$_smarty_tpl);?>
" method="post" class="forms">
<input type="text" name="username" placeholder="输入你的用户名……" x-webkit-speech>
<input type="password" name="password" placeholder="输入你的密码……">
<input type="password" name="password2" placeholder="再次输入你的密码……">
<input type="email" name="email" placeholder="输入你的电子邮箱……">
<input type="url" name="website" placeholder="输入网站方便回访……">
<input type="submit" name="submit" value="立即注册" class="btn">
<a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'login'),$_smarty_tpl);?>
">已有账号？立即登陆</a>
</form>
</div>
</center>
</div>
</body>
</html>