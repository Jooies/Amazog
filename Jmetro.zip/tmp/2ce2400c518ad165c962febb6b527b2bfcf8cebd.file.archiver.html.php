<?php /* Smarty version Smarty-3.0.8, created on 2013-04-21 07:49:22
         compiled from "E:\wamp\www\Jmetro/template\skin/black/archiver.html" */ ?>
<?php /*%%SmartyHeaderCode:2730151732982749ad5-25520136%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2ce2400c518ad165c962febb6b527b2bfcf8cebd' => 
    array (
      0 => 'E:\\wamp\\www\\Jmetro/template\\skin/black/archiver.html',
      1 => 1366445760,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2730151732982749ad5-25520136',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php $_template = new Smarty_Internal_Template("skin/black/header.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?>            
<div class="col12">
<h5>共有<?php echo $_smarty_tpl->getVariable('count')->value;?>
篇文章</h5>
<div id="content">
<ul>
<?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('archiver')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value){
?>
<?php if ($_smarty_tpl->getVariable('newmonth')->value!=$_smarty_tpl->tpl_vars['v']->value['month']){?>
<?php $_smarty_tpl->tpl_vars['newmonth'] = new Smarty_variable($_smarty_tpl->tpl_vars['v']->value['month'], null, null);?>
<li><?php echo $_smarty_tpl->tpl_vars['v']->value['year'];?>
年<?php echo $_smarty_tpl->tpl_vars['v']->value['month'];?>
月
<?php }?>
<li><?php echo $_smarty_tpl->tpl_vars['v']->value['day'];?>
日：<a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'post','pid'=>$_smarty_tpl->tpl_vars['v']->value['pid'],'cid'=>$_smarty_tpl->tpl_vars['v']->value['cid']),$_smarty_tpl);?>
"><?php echo $_smarty_tpl->tpl_vars['v']->value['title'];?>
</a> (<?php echo $_smarty_tpl->tpl_vars['v']->value['m_count'];?>
)</li>
<?php }} ?>
</ul>
</div>
</div>
<?php $_template = new Smarty_Internal_Template("skin/black/sidebar.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?>
<?php $_template = new Smarty_Internal_Template("skin/black/footer.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?>
