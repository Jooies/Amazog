<?php /* Smarty version Smarty-3.0.8, created on 2013-04-29 08:04:58
         compiled from "E:\wamp\www\Jmetro/template\category/admin.html" */ ?>
<?php /*%%SmartyHeaderCode:14987517db92a7573f8-21126589%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e99da2f4f22bd84df19c65ef422db8b6a741df5e' => 
    array (
      0 => 'E:\\wamp\\www\\Jmetro/template\\category/admin.html',
      1 => 1367193896,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14987517db92a7573f8-21126589',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link href="public/css/admin.css" rel="stylesheet" media="screen">
<script type="text/javascript" src="public/js/jquery.js"></script>
<script type="text/javascript" src="public/js/jquery.leanModal.min.js"></script>
<script type="text/javascript">
			$(function() {
    			$("#go").leanModal({ top : 200, overlay : 0.4, closeButton: "#modal_close" });
			});
</script>
</head>
<div class="box">
<div class="pull-left"><a id="go" rel="leanModal" href="#text" class="submit">添加分类</a></div><br><br>
<table width="100%" class="table">
<tr>
<td class="title"><em>分类名称</em></td>
<td class="time" width="10%"><em>动作</em></td>
</tr>
<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('category')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
?>
<tr>
<td><?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>
</td>
<td class="time"><a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'category','a'=>'modify','cid'=>$_smarty_tpl->tpl_vars['value']->value['cid']),$_smarty_tpl);?>
">编辑</a> | <a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'category','a'=>'delete','cid'=>$_smarty_tpl->tpl_vars['value']->value['cid']),$_smarty_tpl);?>
">删除</a></td>
</tr>
<?php }} ?>
</table>
<?php if ($_smarty_tpl->getVariable('pager')->value){?><br>
<?php if ($_smarty_tpl->getVariable('pager')->value['current_page']!=$_smarty_tpl->getVariable('pager')->value['first_page']){?>
<a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'category','a'=>'admin','page'=>$_smarty_tpl->getVariable('pager')->value['first_page']),$_smarty_tpl);?>
">首页</a> |
<a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'category','a'=>'admin','page'=>$_smarty_tpl->getVariable('pager')->value['prev_page']),$_smarty_tpl);?>
">上一页</a> |
<?php }?>
<?php  $_smarty_tpl->tpl_vars['thepage'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('pager')->value['all_pages']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['thepage']->key => $_smarty_tpl->tpl_vars['thepage']->value){
?>
<?php if ($_smarty_tpl->tpl_vars['thepage']->value!=$_smarty_tpl->getVariable('pager')->value['current_page']){?>
<a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'category','a'=>'admin','page'=>$_smarty_tpl->tpl_vars['thepage']->value),$_smarty_tpl);?>
"><?php echo $_smarty_tpl->tpl_vars['thepage']->value;?>
</a>
<?php }else{ ?>
<b><?php echo $_smarty_tpl->tpl_vars['thepage']->value;?>
</b>
<?php }?>
<?php }} ?>              
<?php if ($_smarty_tpl->getVariable('pager')->value['current_page']!=$_smarty_tpl->getVariable('pager')->value['last_page']){?>
<a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'category','a'=>'admin','page'=>$_smarty_tpl->getVariable('pager')->value['next_page']),$_smarty_tpl);?>
">下一页</a> |
<a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'category','a'=>'admin','page'=>$_smarty_tpl->getVariable('pager')->value['last_page']),$_smarty_tpl);?>
">尾页</a>
<?php }?>
<?php }?>
</div>
</div>
<div id="text">
<form action="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'category','a'=>'add'),$_smarty_tpl);?>
" method="post">
<input type="text" name="name" placeholder="请输入分类名...">
<input style="padding:2px 41px" type="submit" name="c_submit" value="添加" class="submit">
<a id="modal_close" class="close" href="#">×</a>
</div>
</div>
</html>

