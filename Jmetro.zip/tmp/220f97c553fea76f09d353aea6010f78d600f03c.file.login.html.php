<?php /* Smarty version Smarty-3.0.8, created on 2013-04-28 20:17:23
         compiled from "E:\wamp\www\Jmetro/template\admin/login.html" */ ?>
<?php /*%%SmartyHeaderCode:8318517d1353b0e4b7-09034709%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '220f97c553fea76f09d353aea6010f78d600f03c' => 
    array (
      0 => 'E:\\wamp\\www\\Jmetro/template\\admin/login.html',
      1 => 1367151442,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8318517d1353b0e4b7-09034709',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<html>
<head>
<title>管理员登陆</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link href="public/css/style.css" rel="stylesheet" media="screen">
</head>
<body style="background:#f1f1f1;">
<div class="full">
<center>
<div class="col3" style="float:center;"><br><br><br><br>
<form action="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'admin','a'=>'login'),$_smarty_tpl);?>
" method="post" class="forms">
<input type="text" name="username" class="input-medium" placeholder="输入你的用户名……">
<input type="password" name="password" class="input-medium" placeholder="输入你的密码……" id="login-name">
<input type="submit" name="submit" value="立即登陆" class="btn"> <a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'index'),$_smarty_tpl);?>
">不是管理员，返回首页！</a>
</form>
</div>
</center>
</div>        
</body>
</html>