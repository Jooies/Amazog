<?php /* Smarty version Smarty-3.0.8, created on 2013-04-28 20:09:05
         compiled from "E:\wamp\www\Jmetro/template\skin/black/main/login.html" */ ?>
<?php /*%%SmartyHeaderCode:818517d1161a13b53-19411888%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '713c4e9926e02daf20d39db3763ffd0d749c0794' => 
    array (
      0 => 'E:\\wamp\\www\\Jmetro/template\\skin/black/main/login.html',
      1 => 1367150944,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '818517d1161a13b53-19411888',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>登陆</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link href="public/css/style.css" rel="stylesheet" media="screen">
</head>
<body style="background:#f1f1f1;">
<div class="container"><div class="col3"><br><br><br><br><h1> 登陆 </h1></div>
<div class="col5"><center><br><br><br><br>
<form action="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'login'),$_smarty_tpl);?>
" method="post" class="forms"><span id="tips"><?php echo $_smarty_tpl->getVariable('tips')->value;?>
</span>
<input type="text" class="login-field" name="username" class="input-medium" placeholder="输入你的用户名……">
<input type="password" class="login-field" name="password" class="input-medium" placeholder="输入你的密码……" id="login-name">
<input type="submit" name="submit" value="立即登陆" class="btn"><a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'register'),$_smarty_tpl);?>
">没有账号？立即注册</a>
</form>
</center>
</div>
</div>        
</body>
</html>