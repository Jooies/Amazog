<?php /* Smarty version Smarty-3.0.8, created on 2013-04-29 07:37:19
         compiled from "E:\wamp\www\Jmetro/template\category/modify.html" */ ?>
<?php /*%%SmartyHeaderCode:9839517db2afae6332-95388201%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c097b176e7e5bee44590a9296979311ec776f46f' => 
    array (
      0 => 'E:\\wamp\\www\\Jmetro/template\\category/modify.html',
      1 => 1364724988,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9839517db2afae6332-95388201',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link href="public/css/bootstrap.css" rel="stylesheet" media="screen">
    </head>
    <div class="container">
        <div class="row">
            <div class="span5 offset5">
                <h2><b>编辑分类</b></h2>
            </div>
        </div>
        <br><br><br>
        <!--form-->
        <form action="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'category','a'=>'modify','cid'=>$_smarty_tpl->getVariable('category')->value['cid']),$_smarty_tpl);?>
" method="post" class="form-inline">
            <!--title-->
            <div class="row">
                <div class="span4">分类名:<br><br>
                        <input type="text" name="name" class="input-block-level" placeholder="Category name" value="<?php echo $_smarty_tpl->getVariable('category')->value['name'];?>
"><br><br>
                        <input type="submit" name="c_submit" value="完成修改" class="btn">
                </div>  
            </div>
                
        </form>
    </div>

</html>
