<?php /* Smarty version Smarty-3.0.8, created on 2013-04-21 07:56:47
         compiled from "E:\wamp\www\Jmetro/template\admin/top.html" */ ?>
<?php /*%%SmartyHeaderCode:1621551732b3fe66250-11744354%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'dc2f24f7f6775d8844b210b5a67d6dfd30e2fbc1' => 
    array (
      0 => 'E:\\wamp\\www\\Jmetro/template\\admin/top.html',
      1 => 1365938208,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1621551732b3fe66250-11744354',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link href="public/css/style.css" rel="stylesheet" media="screen">
</head>
<style>
.nav {margin: 0;width: 98%}
</style>
<body>
<ul class="nav">
<li><a><?php echo $_smarty_tpl->getVariable('title')->value['name'];?>
后台</a></li>
<div class="pull-right">
<li><a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'setup','a'=>'index'),$_smarty_tpl);?>
" target="main">系统设置</a></li>
<li><a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'admin','a'=>'logout'),$_smarty_tpl);?>
" target="_top">注销</a></li>
<li><a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'index'),$_smarty_tpl);?>
" target="_top">返回首页</a></li>
</div>
</ul>
</html>
