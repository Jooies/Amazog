<?php /* Smarty version Smarty-3.0.8, created on 2013-04-29 07:56:05
         compiled from "E:\wamp\www\Jmetro/template\admin/index.html" */ ?>
<?php /*%%SmartyHeaderCode:14539517db715ac2423-89191554%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'aa253153c30f656d78ad8bf7e1071c2ae14fbb47' => 
    array (
      0 => 'E:\\wamp\\www\\Jmetro/template\\admin/index.html',
      1 => 1367193364,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14539517db715ac2423-89191554',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $_smarty_tpl->getVariable('title')->value['name'];?>
 - 管理员页面</title>
</head>
<frameset rows="45,*" frameborder="0">
<frame src="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'admin','a'=>'top'),$_smarty_tpl);?>
" name="top">
<frameset cols="150,*">
<frame src="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'admin','a'=>'menu'),$_smarty_tpl);?>
" name="menu">
<frame src="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'post','a'=>'add'),$_smarty_tpl);?>
" name="main">
</frameset>
</frameset>
</html>