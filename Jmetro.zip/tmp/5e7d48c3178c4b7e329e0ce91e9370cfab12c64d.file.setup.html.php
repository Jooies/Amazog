<?php /* Smarty version Smarty-3.0.8, created on 2013-04-21 10:38:04
         compiled from "E:\wamp\www\Jmetro/template\admin/setup.html" */ ?>
<?php /*%%SmartyHeaderCode:305385173510cdfbea7-82212124%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5e7d48c3178c4b7e329e0ce91e9370cfab12c64d' => 
    array (
      0 => 'E:\\wamp\\www\\Jmetro/template\\admin/setup.html',
      1 => 1366511882,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '305385173510cdfbea7-82212124',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_function_html_options')) include 'E:\wamp\www\Jmetro\system\Drivers\Smarty\plugins\function.html_options.php';
?><html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link href="public/css/admin.css" rel="stylesheet" media="screen">
</head>
<body>
<div class="box">
<div class="form-list">
<h1><span class="fui-settings-24"></span></h1>
<form action="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'setup','a'=>'index_update'),$_smarty_tpl);?>
" method="post">
<h3>全局设置</h3>
<div class="row">
<label class="label"><em>*</em>网站标题：</label>
<input type="text" name="title" value="<?php echo $_smarty_tpl->getVariable('title')->value;?>
" placeholder="输入网站标题...">
</div>
<div class="row">
<label class="label"><em>*</em>网站描述：</label>
<input type="text" name="description" value="<?php echo $_smarty_tpl->getVariable('description')->value;?>
" placeholder="输入网站描述...">
</div>
<div class="row">
<label class="label"><em>*</em>网站关键词：</label>
<input type="text" name="keywords" value="<?php echo $_smarty_tpl->getVariable('keywords')->value;?>
" placeholder="输入网站关键词...">
</div>
<div class="row">
<label class="label">站长邮箱：</label>
<input type="text" name="mail" value="<?php echo $_smarty_tpl->getVariable('email')->value;?>
" placeholder="输入邮箱...">
</div>
<div class="row">
<label class="label">首页文章数：</label>
<input type="text" name="main_count" value="<?php echo $_smarty_tpl->getVariable('main_count')->value;?>
" onkeyup="this.value=this.value.replace(/\D/g,'')" onafterpaste="this.value=this.value.replace(/\D/g,'')">
</div>
<div class="row">
<label class="label">侧边栏文章数：</label>
<input type="text" name="siderbar_post" value="<?php echo $_smarty_tpl->getVariable('siderbar_post')->value;?>
" onkeyup="this.value=this.value.replace(/\D/g,'')" onafterpaste="this.value=this.value.replace(/\D/g,'')">
</div>
<div class="row">
<label class="label">侧边栏评论数：</label>
<input type="text" name="siderbar_comments" value="<?php echo $_smarty_tpl->getVariable('siderbar_comments')->value;?>
" onkeyup="this.value=this.value.replace(/\D/g,'')" onafterpaste="this.value=this.value.replace(/\D/g,'')">
</div>
<div class="row">
<label class="label">网站公告：</label>
<div class="collection">
<textarea class="textarea" name="n" rows="5" cols=""><?php echo $_smarty_tpl->getVariable('announcement')->value;?>
</textarea>
</div>
</div>
<h3>评论设置</h3>
<div class="row">
<label class="label"><em>*</em>开启评论：</label>
<select id="com" name="com">
<?php if ($_smarty_tpl->getVariable('comments')->value){?>
<option value="true" selected>全站开启评论
<option value="false">全站关闭评论
<?php }else{ ?>
<option value="true">全站开启评论
<option value="false" selected>全站关闭评论
<?php }?>
</select>
</div>
<div class="row">
<label class="label"><em>*</em>评论邮件通知：</label>
<select id="email" name="email">
<?php if ($_smarty_tpl->getVariable('comments_mail')->value){?>
<option value="true" selected>开启邮件通知
<option value="false">关闭邮件通知
<?php }else{ ?>
<option value="true">开启邮件通知
<option value="false" selected>关闭邮件通知
<?php }?>
</select>
</div>
<div class="row">
<label class="label">Smtp服务器：</label>
<input type="text" name="smtpserver" value="<?php echo $_smarty_tpl->getVariable('smtpserver')->value;?>
" placeholder="输入网站关键词...">
</div>
<div class="row">
<label class="label">Smtp端口：</label>
<input type="text" name="smtpserverport" value="<?php echo $_smarty_tpl->getVariable('smtpserverport')->value;?>
" onkeyup="this.value=this.value.replace(/\D/g,'')" onafterpaste="this.value=this.value.replace(/\D/g,'')">
</div>
<div class="row">
<label class="label">Smtp用户：</label>
<input type="text" name="smtpuser" value="<?php echo $_smarty_tpl->getVariable('smtpuser')->value;?>
">
</div>
<div class="row">
<label class="label">Smtp密码：</label>
<input type="text" name="smtppass" value="<?php echo $_smarty_tpl->getVariable('smtppass')->value;?>
">
</div>
<div class="row">
<label class="label">内容评论数：</label>
<input type="text" name="post_comments" value="<?php echo $_smarty_tpl->getVariable('post_comments')->value;?>
" onkeyup="this.value=this.value.replace(/\D/g,'')" onafterpaste="this.value=this.value.replace(/\D/g,'')">
</div>
<div class="row">
<label class="label">评论间隔时间：</label>
<input type="text" name="post_time" value="<?php echo $_smarty_tpl->getVariable('post_time')->value;?>
" onkeyup="this.value=this.value.replace(/\D/g,'')" onafterpaste="this.value=this.value.replace(/\D/g,'')">
</div>
<h3>主题设置</h3>
<div class="row">
<label class="label"><em>*</em>自定义主题：</label>
<select name='skin'>
    <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->getVariable('skin')->value,'selected'=>$_smarty_tpl->getVariable('skinname')->value),$_smarty_tpl);?>

</select>
</div><br>
<input type="submit" name="save" value="完成设置" class="submit">
</form>
</div>
</div>
</body>
</html>

