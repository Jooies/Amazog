<?php /* Smarty version Smarty-3.0.8, created on 2013-04-21 11:50:18
         compiled from "E:\wamp\www\Jmetro/template\skin/black/header.html" */ ?>
<?php /*%%SmartyHeaderCode:18781517361fab03387-72365349%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '33ccb8e3eb91fbab1ab95f00d9559b380ed592ee' => 
    array (
      0 => 'E:\\wamp\\www\\Jmetro/template\\skin/black/header.html',
      1 => 1366516216,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '18781517361fab03387-72365349',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link href="public/css/style.css" rel="stylesheet" media="screen">
<script src="public/js/jquery.js"></script>
<title><?php echo $_smarty_tpl->getVariable('title')->value;?>
<?php if ($_smarty_tpl->getVariable('page')->value['title']||$_smarty_tpl->getVariable('post')->value['title']){?> - <?php echo $_smarty_tpl->getVariable('page')->value['title'];?>
<?php echo $_smarty_tpl->getVariable('post')->value['title'];?>
<?php }?></title>
<meta name="keywords" content="<?php echo $_smarty_tpl->getVariable('keywords')->value;?>
" />
<meta name="description" content="<?php echo $_smarty_tpl->getVariable('description')->value;?>
" />
<!-- HTML5 IE Enabling Script -->
<!--[if lt IE 9]><script src="public/js/html5.js"></script>
<![endif]-->
</head>
<html>
<body>
<div class="container">
<div class="content">
<center>
<a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'index'),$_smarty_tpl);?>
"><h1 class="logo"><?php echo $_smarty_tpl->getVariable('title')->value;?>
</h1></a><br>
<div class="desc"><?php echo $_smarty_tpl->getVariable('description')->value;?>
</div>
<form action="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'index'),$_smarty_tpl);?>
" class="search" method="get"><input id="search-input" type="text" name="s" class="inputbox" placeholder="搜索…" x-webkit-speech/></form>
</center>
</div>
</div>
<nav class="nav">
<center>
<div class="container">
<ul id="nav">
<li><a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'index'),$_smarty_tpl);?>
">首页</a></li>
<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('pagenav')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
?><li><a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'page','pid'=>$_smarty_tpl->tpl_vars['value']->value['pid']),$_smarty_tpl);?>
"><?php echo $_smarty_tpl->tpl_vars['value']->value['title'];?>
</a></li><?php }} ?>
<li><a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'archiver'),$_smarty_tpl);?>
">归档</a></li>
<div class="pull-right">
<li class="login"><?php if ($_smarty_tpl->getVariable('username')->value){?>
<img src="<?php echo $_smarty_tpl->getVariable('avatar_me')->value;?>
" width="20" height="20"/><a class="username"><?php echo $_smarty_tpl->getVariable('username')->value;?>
</a><a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'logout'),$_smarty_tpl);?>
">注销</a>
<?php }else{ ?>
<a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'login'),$_smarty_tpl);?>
">登陆</a> <a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'register'),$_smarty_tpl);?>
">注册</a>
<?php }?></li>
</div>
</ul>
</div>
</center>
</nav>
<div class="container">
<div class="content">