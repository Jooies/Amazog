<?php /* Smarty version Smarty-3.0.8, created on 2013-04-20 20:58:48
         compiled from "E:\wamp\www\Jmetro/template\skin/black/detail.html" */ ?>
<?php /*%%SmartyHeaderCode:12018517291085246f0-26208365%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f5df6b6cb84bcef9787d3e86abda30e04331bbca' => 
    array (
      0 => 'E:\\wamp\\www\\Jmetro/template\\skin/black/detail.html',
      1 => 1366456587,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12018517291085246f0-26208365',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_modifier_date_format')) include 'E:\wamp\www\Jmetro\system\Drivers\Smarty\plugins\modifier.date_format.php';
?><?php $_template = new Smarty_Internal_Template("skin/black/header.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?>  
<div class="col12">
<h6>
<div class="pull-right">
发布时间：<?php echo smarty_modifier_date_format($_smarty_tpl->getVariable('post')->value['time'],"%Y-%m-%d");?>
 /
分类：<a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'index','cid'=>$_smarty_tpl->getVariable('post')->value['cid']),$_smarty_tpl);?>
"><?php echo $_smarty_tpl->getVariable('category')->value;?>
</a> /
<a href="#comments"><?php echo $_smarty_tpl->getVariable('post')->value['m_count'];?>
 个评论</a>
</div>
</h6>
<h5><?php echo $_smarty_tpl->getVariable('post')->value['title'];?>
</h5>
<div id="content"><?php echo $_smarty_tpl->getVariable('post')->value['content'];?>
</div>
<div id="tag">
标签: <?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('tag')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
?><a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','tag'=>$_smarty_tpl->tpl_vars['value']->value),$_smarty_tpl);?>
" class="tag"><?php echo $_smarty_tpl->tpl_vars['value']->value;?>
</a><?php }} ?>
</div>
<?php $_template = new Smarty_Internal_Template("skin/black/comment.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?>
<?php $_template = new Smarty_Internal_Template("skin/black/sidebar.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?>
<?php $_template = new Smarty_Internal_Template("skin/black/footer.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?>