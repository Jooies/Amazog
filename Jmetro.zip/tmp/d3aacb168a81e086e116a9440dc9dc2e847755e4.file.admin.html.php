<?php /* Smarty version Smarty-3.0.8, created on 2013-04-29 07:37:21
         compiled from "E:\wamp\www\Jmetro/template\admin/user/admin.html" */ ?>
<?php /*%%SmartyHeaderCode:24444517db2b17371b9-62018455%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd3aacb168a81e086e116a9440dc9dc2e847755e4' => 
    array (
      0 => 'E:\\wamp\\www\\Jmetro/template\\admin/user/admin.html',
      1 => 1365053198,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '24444517db2b17371b9-62018455',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link href="public/css/admin.css" rel="stylesheet" media="screen">
</head>
<div class="box">
<table width="100%" class="table">
<tr>
<td>用户ID</td>
<td>用户名</td>
<td>邮箱</td>
<td>网站</td>
<td>管理</td>
 </tr>
<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('user')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
?>
<tr>
<td width="8%"><?php echo $_smarty_tpl->tpl_vars['value']->value['id'];?>
</td>
<td width="30%"><?php echo $_smarty_tpl->tpl_vars['value']->value['username'];?>
</td>
<td width="20%"><?php echo $_smarty_tpl->tpl_vars['value']->value['email'];?>
</td>
<td><?php echo $_smarty_tpl->tpl_vars['value']->value['website'];?>
</td>
<td width="12%">编辑 | 删除</td>
</tr>
<?php }} ?>
</table>
<?php if ($_smarty_tpl->getVariable('pager')->value){?><br>
<?php if ($_smarty_tpl->getVariable('pager')->value['current_page']!=$_smarty_tpl->getVariable('pager')->value['first_page']){?>
<a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'page','a'=>'admin','page'=>$_smarty_tpl->getVariable('pager')->value['first_page']),$_smarty_tpl);?>
">首页</a> |
<a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'page','a'=>'admin','page'=>$_smarty_tpl->getVariable('pager')->value['prev_page']),$_smarty_tpl);?>
">上一页</a> |
<?php }?>
<?php  $_smarty_tpl->tpl_vars['thepage'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('pager')->value['all_pages']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['thepage']->key => $_smarty_tpl->tpl_vars['thepage']->value){
?>
<?php if ($_smarty_tpl->tpl_vars['thepage']->value!=$_smarty_tpl->getVariable('pager')->value['current_page']){?>
<a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'page','a'=>'admin','page'=>$_smarty_tpl->tpl_vars['thepage']->value),$_smarty_tpl);?>
"><?php echo $_smarty_tpl->tpl_vars['thepage']->value;?>
</a>
<?php }else{ ?>
<b><?php echo $_smarty_tpl->tpl_vars['thepage']->value;?>
</b>
<?php }?>
<?php }} ?>
<?php if ($_smarty_tpl->getVariable('pager')->value['current_page']!=$_smarty_tpl->getVariable('pager')->value['last_page']){?>
<a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'page','a'=>'admin','page'=>$_smarty_tpl->getVariable('pager')->value['next_page']),$_smarty_tpl);?>
">下一页</a> |
<a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'page','a'=>'admin','page'=>$_smarty_tpl->getVariable('pager')->value['last_page']),$_smarty_tpl);?>
">尾页</a>
<?php }?>
<?php }?>
</div>
</html>

