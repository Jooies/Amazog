<?php /* Smarty version Smarty-3.0.8, created on 2013-04-29 06:16:09
         compiled from "E:\wamp\www\Jmetro/template\admin/post/add.html" */ ?>
<?php /*%%SmartyHeaderCode:16559517d9fa9872486-27100628%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7d6a850e117cc9f81a9614ced8403660f9f3eff9' => 
    array (
      0 => 'E:\\wamp\\www\\Jmetro/template\\admin/post/add.html',
      1 => 1367187367,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16559517d9fa9872486-27100628',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link href="public/css/admin.css" rel="stylesheet" media="screen">
<style>
.box {text-align: left;width: 725px}
.input-block-level {width: 545px !important;}
select {width: 100px !important;}
</style>
</head>
<div class="box">
<!--form-->
<form action="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'post','a'=>'add'),$_smarty_tpl);?>
" method="post">
<!--title-->
<div class="row">
<label class="label">文章标题：</label>
<input type="text" name="title" class="input-block-level" placeholder="请输入文章标题...">
<select name="category">
<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('category')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
?>
<option><?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>
</option>
<?php }} ?>
</select>
</div><br>
<textarea name="content"></textarea><br><br>
<div class="row">
<label class="label">文章标签: </label>
<input type="text" name="tags" class="input-block-level" placeholder="请输入文章标签..."><br><br>
<input type="submit" name="c_submit" value="撰写完成" class="submit">
</div>      
</form>
</html>