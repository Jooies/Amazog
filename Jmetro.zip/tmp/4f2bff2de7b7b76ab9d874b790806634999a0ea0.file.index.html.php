<?php /* Smarty version Smarty-3.0.8, created on 2013-04-21 10:40:40
         compiled from "E:\wamp\www\Jmetro/template\skin/black/index.html" */ ?>
<?php /*%%SmartyHeaderCode:1723517351a81a2fc5-50348613%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4f2bff2de7b7b76ab9d874b790806634999a0ea0' => 
    array (
      0 => 'E:\\wamp\\www\\Jmetro/template\\skin/black/index.html',
      1 => 1366512005,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1723517351a81a2fc5-50348613',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_modifier_date_format')) include 'E:\wamp\www\Jmetro\system\Drivers\Smarty\plugins\modifier.date_format.php';
?><?php $_template = new Smarty_Internal_Template("skin/black/header.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?>
<div class="col12">
<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('post')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
?>
<h6>
<div class="pull-right">
<?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['value']->value['time'],"%Y-%m-%d");?>
 / 
<a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'post','pid'=>$_smarty_tpl->tpl_vars['value']->value['pid']),$_smarty_tpl);?>
#comments"><?php echo $_smarty_tpl->tpl_vars['value']->value['m_count'];?>
 个评论</a>
</div>
</h6>
<h5><a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'post','pid'=>$_smarty_tpl->tpl_vars['value']->value['pid']),$_smarty_tpl);?>
"><?php echo $_smarty_tpl->tpl_vars['value']->value['title'];?>
</a></h5>
<div id="content"><?php echo content(array('c'=>$_smarty_tpl->tpl_vars['value']->value['content']),$_smarty_tpl);?>
</div>
<?php }} ?>
<?php echo $_smarty_tpl->getVariable('postno')->value;?>

<?php if ($_smarty_tpl->getVariable('pager')->value){?><div class="container_bottom"><ul class="page-navigator">
<?php if ($_smarty_tpl->getVariable('pager')->value['current_page']!=$_smarty_tpl->getVariable('pager')->value['first_page']){?>
<li><a href="<?php echo $_smarty_tpl->getVariable('page_prev')->value;?>
">上一页</a></li>
<?php }?>
<?php  $_smarty_tpl->tpl_vars['thepage'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('pager')->value['mid_pages']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['thepage']->key => $_smarty_tpl->tpl_vars['thepage']->value){
?>
<?php if ($_smarty_tpl->tpl_vars['thepage']->value!=$_smarty_tpl->getVariable('pager')->value['current_page']){?>
<li><?php if ($_smarty_tpl->getVariable('cid')->value){?><a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'index','cid'=>$_smarty_tpl->getVariable('cid')->value['cid'],'page'=>$_smarty_tpl->tpl_vars['thepage']->value),$_smarty_tpl);?>
">
	<?php }else{ ?><?php if ($_smarty_tpl->getVariable('s')->value){?><a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'index','s'=>$_smarty_tpl->getVariable('s')->value,'page'=>$_smarty_tpl->tpl_vars['thepage']->value),$_smarty_tpl);?>
">
	<?php }else{ ?><?php if ($_smarty_tpl->getVariable('tag')->value){?><a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'index','tag'=>$_smarty_tpl->getVariable('tag')->value,'page'=>$_smarty_tpl->tpl_vars['thepage']->value),$_smarty_tpl);?>
">
	<?php }else{ ?><a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'index','page'=>$_smarty_tpl->tpl_vars['thepage']->value),$_smarty_tpl);?>
"><?php }?><?php }?>
	<?php }?><?php echo $_smarty_tpl->tpl_vars['thepage']->value;?>
</a></li>
<?php }else{ ?>
<li><a class="active"><?php echo $_smarty_tpl->tpl_vars['thepage']->value;?>
</a></li>
<?php }?>
<?php }} ?>
<?php if ($_smarty_tpl->getVariable('pager')->value['current_page']!=$_smarty_tpl->getVariable('pager')->value['last_page']){?>
<li><a href="<?php echo $_smarty_tpl->getVariable('page_next')->value;?>
">下一页</a></li>
<?php }?>
</ul></div>
<?php }?>
<?php $_template = new Smarty_Internal_Template("skin/black/sidebar.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?>
<?php $_template = new Smarty_Internal_Template("skin/black/footer.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?>
