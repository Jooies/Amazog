<?php /* Smarty version Smarty-3.0.8, created on 2013-04-29 07:55:31
         compiled from "E:\wamp\www\Jmetro/template\admin/post/admin.html" */ ?>
<?php /*%%SmartyHeaderCode:17788517db6f3c5f088-07682564%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8684f4d3267ed11842b8fb3f6adfdcacabfe4cce' => 
    array (
      0 => 'E:\\wamp\\www\\Jmetro/template\\admin/post/admin.html',
      1 => 1367193330,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17788517db6f3c5f088-07682564',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_modifier_date_format')) include 'E:\wamp\www\Jmetro\system\Drivers\Smarty\plugins\modifier.date_format.php';
?><html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link href="public/css/admin.css" rel="stylesheet" media="screen">
</head>
<div class="box">
<div class="pull-left"><a id="go" rel="leanModal" href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'post','a'=>'add'),$_smarty_tpl);?>
" class="submit">撰写文章</a></div><br><br>
<table width="100%" class="table">
<tr>
<td class="time"><center><em>评论</em></center></td>
<td class="title"><em>文章标题</em></td>
<td class="time"><em>日期</em></td>
<td class="time"><em>动作</em></td>
</tr>
<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('post')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
?>
<tr>
<td width="4%"><center><span style="color:#fff;background:#8B8386;padding-left:4px;padding-right:4px;border-radius:2px;"><?php echo $_smarty_tpl->tpl_vars['value']->value['m_count'];?>
</span></center></td>
<td><?php echo $_smarty_tpl->tpl_vars['value']->value['title'];?>
</td>
<td width="18%" class="time" title="<?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['value']->value['time'],'%Y-%m-%d %k:%i');?>
"><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['value']->value['time'],'%b %d,%Y');?>
</td>
<td width="8%" class="time"><a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'post','a'=>'modify','pid'=>$_smarty_tpl->tpl_vars['value']->value['pid']),$_smarty_tpl);?>
">编辑</a> | <a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'post','a'=>'delete','pid'=>$_smarty_tpl->tpl_vars['value']->value['pid']),$_smarty_tpl);?>
" onclick="if(confirm('确实要删除此条记录吗？')) return true;else return false;">删除</a></td>
</tr>
<?php }} ?>
</table>
<?php if ($_smarty_tpl->getVariable('pager')->value){?><br>
<?php if ($_smarty_tpl->getVariable('pager')->value['current_page']!=$_smarty_tpl->getVariable('pager')->value['first_page']){?>
<a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'post','a'=>'admin','page'=>$_smarty_tpl->getVariable('pager')->value['first_page']),$_smarty_tpl);?>
">首页</a> |
<a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'post','a'=>'admin','page'=>$_smarty_tpl->getVariable('pager')->value['prev_page']),$_smarty_tpl);?>
">上一页</a> |
<?php }?>
<?php  $_smarty_tpl->tpl_vars['thepage'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('pager')->value['all_pages']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['thepage']->key => $_smarty_tpl->tpl_vars['thepage']->value){
?>
<?php if ($_smarty_tpl->tpl_vars['thepage']->value!=$_smarty_tpl->getVariable('pager')->value['current_page']){?>
 <a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'post','a'=>'admin','page'=>$_smarty_tpl->tpl_vars['thepage']->value),$_smarty_tpl);?>
"><?php echo $_smarty_tpl->tpl_vars['thepage']->value;?>
</a>
<?php }else{ ?>
<b><?php echo $_smarty_tpl->tpl_vars['thepage']->value;?>
</b>
<?php }?>
<?php }} ?>              
<?php if ($_smarty_tpl->getVariable('pager')->value['current_page']!=$_smarty_tpl->getVariable('pager')->value['last_page']){?>
<a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'post','a'=>'admin','page'=>$_smarty_tpl->getVariable('pager')->value['next_page']),$_smarty_tpl);?>
">下一页</a> |
<a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'post','a'=>'admin','page'=>$_smarty_tpl->getVariable('pager')->value['last_page']),$_smarty_tpl);?>
">尾页</a>
<?php }?>
<?php }?>
</div>
</html>

