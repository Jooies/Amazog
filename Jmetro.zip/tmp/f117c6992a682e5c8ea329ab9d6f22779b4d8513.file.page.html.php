<?php /* Smarty version Smarty-3.0.8, created on 2013-04-20 20:56:29
         compiled from "E:\wamp\www\Jmetro/template\skin/black/page.html" */ ?>
<?php /*%%SmartyHeaderCode:187015172907d2a2b33-60361481%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f117c6992a682e5c8ea329ab9d6f22779b4d8513' => 
    array (
      0 => 'E:\\wamp\\www\\Jmetro/template\\skin/black/page.html',
      1 => 1366445240,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '187015172907d2a2b33-60361481',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_modifier_date_format')) include 'E:\wamp\www\Jmetro\system\Drivers\Smarty\plugins\modifier.date_format.php';
?><?php $_template = new Smarty_Internal_Template("skin/black/header.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?>            
<div class="col12">
<h6>
<div class="pull-right">
最后修改时间：<?php echo smarty_modifier_date_format($_smarty_tpl->getVariable('page')->value['time'],"%Y-%m-%d");?>
 / 
<a href="#comments"><?php echo $_smarty_tpl->getVariable('page')->value['m_count'];?>
 个评论</a>
</div>
</h6>
<h5><?php echo $_smarty_tpl->getVariable('page')->value['title'];?>
</h5>
<div id="content">
<?php echo $_smarty_tpl->getVariable('page')->value['content'];?>

</div>
<?php $_template = new Smarty_Internal_Template("skin/black/comment.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?>
<?php $_template = new Smarty_Internal_Template("skin/black/sidebar.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?>
<?php $_template = new Smarty_Internal_Template("skin/black/footer.html", $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate(); $_template->rendered_content = null;?><?php unset($_template);?>
