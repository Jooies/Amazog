<?php /* Smarty version Smarty-3.0.8, created on 2013-04-21 07:56:48
         compiled from "E:\wamp\www\Jmetro/template\admin/menu.html" */ ?>
<?php /*%%SmartyHeaderCode:2418651732b4010bf75-56173223%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '609ce07adb183689eb77bfdf448ebc3b0cf76225' => 
    array (
      0 => 'E:\\wamp\\www\\Jmetro/template\\admin/menu.html',
      1 => 1365052495,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2418651732b4010bf75-56173223',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link href="public/css/style.css" rel="stylesheet" media="screen">
</head>
<body>
<center>
<h5>文章设置选项</h5>
<a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'post','a'=>'add'),$_smarty_tpl);?>
" target="main">撰写文章</a> | 
<a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'post','a'=>'admin'),$_smarty_tpl);?>
" target="main">管理文章</a><br>
<a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'category','a'=>'add'),$_smarty_tpl);?>
" target="main">添加分类</a> | 
<a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'category','a'=>'admin'),$_smarty_tpl);?>
" target="main">管理分类</a>
</center>
<!--post block-->
<center>
<h5>页面设置选项</h5>
<a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'page','a'=>'add'),$_smarty_tpl);?>
" target="main">添加页面</a> | 
<a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'page','a'=>'admin'),$_smarty_tpl);?>
" target="main">管理页面</a>
</center>
<!--page block-->
<center>
<h5>用户设置选项</h5>
<a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'register'),$_smarty_tpl);?>
" target="main">注册用户</a> | 
<a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'admin','a'=>'user'),$_smarty_tpl);?>
" target="main">用户管理</a>
</center>
<!--user block-->
</div>
</body>
</html>