<?php /* Smarty version Smarty-3.0.8, created on 2013-04-28 20:16:44
         compiled from "E:\wamp\www\Jmetro/template\skin/black/sidebar.html" */ ?>
<?php /*%%SmartyHeaderCode:8761517d132c33a103-89587419%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b7e3c63a27f88f00a43176456b8871750e9df797' => 
    array (
      0 => 'E:\\wamp\\www\\Jmetro/template\\skin/black/sidebar.html',
      1 => 1367151403,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8761517d132c33a103-89587419',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<div class="sidebar">
<div class="col3">
<h3>最新文章</h3><ul>
<?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('postnav')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value){
?>
<li><a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'post','pid'=>$_smarty_tpl->tpl_vars['v']->value['pid']),$_smarty_tpl);?>
"><?php echo $_smarty_tpl->tpl_vars['v']->value['title'];?>
</a></li>
<?php }} ?></ul>
</div>
<div class="col3">
<h3>最新评论</h3><ul>
<?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('commentsnav')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value){
?>
<li><a href="<?php echo $_smarty_tpl->tpl_vars['v']->value['website'];?>
"><?php echo $_smarty_tpl->tpl_vars['v']->value['m_author'];?>
</a>：<?php echo $_smarty_tpl->tpl_vars['v']->value['content'];?>
</li>
<?php }} ?></ul>
</div>
<div class="col3">
<h3>文章分类</h3><ul>
<?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('categorynav')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value){
?>
<li><a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'index','cid'=>$_smarty_tpl->tpl_vars['v']->value['cid']),$_smarty_tpl);?>
"><?php echo $_smarty_tpl->tpl_vars['v']->value['name'];?>
</a></li>
<?php }} ?></ul>
</div>
<div class="col3">
<h3>文章标签</h3><ul>
<?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('tagnav')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value){
?>
<a style="font-size:<?php if ($_smarty_tpl->tpl_vars['v']->value['count']<10){?><?php echo $_smarty_tpl->tpl_vars['v']->value['count']+12;?>
px;<?php }else{ ?>24px;<?php }?>" href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'index','tag'=>$_smarty_tpl->tpl_vars['v']->value['name']),$_smarty_tpl);?>
"><?php echo $_smarty_tpl->tpl_vars['v']->value['name'];?>
</a> 
<?php }} ?>
</ul>
</div>
</div>