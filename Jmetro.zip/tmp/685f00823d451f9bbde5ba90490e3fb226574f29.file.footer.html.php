<?php /* Smarty version Smarty-3.0.8, created on 2013-04-20 20:56:29
         compiled from "E:\wamp\www\Jmetro/template\skin/black/footer.html" */ ?>
<?php /*%%SmartyHeaderCode:268895172907d88c1c8-85641920%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '685f00823d451f9bbde5ba90490e3fb226574f29' => 
    array (
      0 => 'E:\\wamp\\www\\Jmetro/template\\skin/black/footer.html',
      1 => 1365215892,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '268895172907d88c1c8-85641920',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
</div>
</div>
</div>
<div class="col12">
<center>CopyRight © 2012 - 2013 All Rights Reserved.Theme by Jooies.</center></div>
<script>
      var buoop = {vs:{i:8,f:3.6,o:10.6,s:3.2,n:9}} 
      buoop.ol = window.onload; 
      window.onload=function(){ 
       try {if ($buoop.ol) $buoop.ol();}catch (e) {} 
       var e = document.createElement("script"); 
       e.setAttribute("type", "text/javascript"); 
       e.setAttribute("src", "http://browser-update.org/update.js"); 
       document.body.appendChild(e); 
      } 
</script>
</body>
</html>