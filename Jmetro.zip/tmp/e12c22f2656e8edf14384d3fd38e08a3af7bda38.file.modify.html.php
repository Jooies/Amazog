<?php /* Smarty version Smarty-3.0.8, created on 2013-04-29 07:00:22
         compiled from "E:\wamp\www\Jmetro/template\admin/post/modify.html" */ ?>
<?php /*%%SmartyHeaderCode:14966517daa0698f073-49078875%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e12c22f2656e8edf14384d3fd38e08a3af7bda38' => 
    array (
      0 => 'E:\\wamp\\www\\Jmetro/template\\admin/post/modify.html',
      1 => 1367190020,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14966517daa0698f073-49078875',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link href="public/css/admin.css" rel="stylesheet" media="screen">
<style>
.box {text-align: left;width: 725px}
.input-block-level {width: 545px !important;}
select {width: 100px !important;}
</style>
</head>
<div class="box">
<!--form-->
<form action="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'post','a'=>'modify','pid'=>$_smarty_tpl->getVariable('post')->value['pid']),$_smarty_tpl);?>
" method="post" class="form-inline">
<!--title-->
<div class="row">
<label class="label">文章标题：</label>
<input type="text" name="title" class="input-block-level"  placeholder="请输入文章标题..." value="<?php echo $_smarty_tpl->getVariable('post')->value['title'];?>
">
<select name="category">
<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('category')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
?>
<option><?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>
</option>
<?php }} ?>
</select>
</div><br>
<textarea name="content" class="widgEditor" rows="10" cols="800"><?php echo $_smarty_tpl->getVariable('content')->value;?>
</textarea><br><br>
<div class="row">
<label class="label">文章标签: </label>
<input type="text" name="tags" class="input-block-level"  placeholder="请输入文章标签..." value="<?php echo $_smarty_tpl->getVariable('post')->value['tags'];?>
"><br><br>
<input type="submit" name="p_submit" value="保存文章" class="submit">
</form>
</div>
</html>
