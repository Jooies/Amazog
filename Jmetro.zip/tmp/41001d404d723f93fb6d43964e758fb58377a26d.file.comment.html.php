<?php /* Smarty version Smarty-3.0.8, created on 2013-04-29 08:01:54
         compiled from "E:\wamp\www\Jmetro/template\skin/black/comment.html" */ ?>
<?php /*%%SmartyHeaderCode:14359517db872f18787-74192148%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '41001d404d723f93fb6d43964e758fb58377a26d' => 
    array (
      0 => 'E:\\wamp\\www\\Jmetro/template\\skin/black/comment.html',
      1 => 1367193714,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14359517db872f18787-74192148',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_modifier_date_format')) include 'E:\wamp\www\Jmetro\system\Drivers\Smarty\plugins\modifier.date_format.php';
?><script>
function reply(name){
 document.comment.content.focus();
 document.comment.content.value="<em>回复 @"+name+"：</em>";
}
</script>
<ul class="page-navigator">
<?php if ($_smarty_tpl->getVariable('pager')->value){?>
<?php if ($_smarty_tpl->getVariable('pager')->value['current_page']!=$_smarty_tpl->getVariable('pager')->value['first_page']){?>
<li><a href="<?php echo $_smarty_tpl->getVariable('page_prev')->value;?>
">上一页</a></li>
<?php }?>
<?php  $_smarty_tpl->tpl_vars['thepage'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('pager')->value['mid_pages']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['thepage']->key => $_smarty_tpl->tpl_vars['thepage']->value){
?>
<?php if ($_smarty_tpl->tpl_vars['thepage']->value!=$_smarty_tpl->getVariable('pager')->value['current_page']){?>
<li>
<?php if ($_smarty_tpl->getVariable('page')->value['pid']){?><a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'page','pid'=>$_smarty_tpl->getVariable('page')->value['pid'],'page'=>$_smarty_tpl->tpl_vars['thepage']->value),$_smarty_tpl);?>
#comments">
<?php }else{ ?><a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'post','pid'=>$_smarty_tpl->getVariable('post')->value['pid'],'page'=>$_smarty_tpl->tpl_vars['thepage']->value),$_smarty_tpl);?>
#comments">
<?php }?>
<?php echo $_smarty_tpl->tpl_vars['thepage']->value;?>
</a></li>
<?php }else{ ?>
<li><a class="active"><?php echo $_smarty_tpl->tpl_vars['thepage']->value;?>
</a></li>
<?php }?>
<?php }} ?>
<?php if ($_smarty_tpl->getVariable('pager')->value['current_page']!=$_smarty_tpl->getVariable('pager')->value['last_page']){?>
<li><a href="<?php echo $_smarty_tpl->getVariable('page_next')->value;?>
">下一页</a></li>
<?php }?>
<?php }else{ ?><?php }?></ul>
<div id="comments">
<ul class="comment-new-list-ul">
<?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('comments')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value){
?>
<div class="comments">
<li id="comment_<?php echo $_smarty_tpl->tpl_vars['value']->value['m_id'];?>
">
<a target="_blank" class="comment-new-list-avatar"><img src="<?php echo togetavatar(array('gravatar_id'=>$_smarty_tpl->tpl_vars['value']->value['email'],'size'=>20),$_smarty_tpl);?>
" alt="" /></a>
<a href="<?php echo $_smarty_tpl->tpl_vars['value']->value['website'];?>
" target="_blank"><?php echo $_smarty_tpl->tpl_vars['value']->value['m_author'];?>
</a><span class="comments-time"><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['value']->value['time'],"%Y-%m-%d");?>
</span><?php if ($_smarty_tpl->getVariable('username')->value){?><a href="#text" onclick="javascript:reply('<?php echo $_smarty_tpl->tpl_vars['value']->value['m_author'];?>
','<?php echo $_smarty_tpl->tpl_vars['value']->value['website'];?>
')" class="comment-back">回复</a>
<?php }else{ ?><?php }?>
<div class="comment-new-list-text"><?php echo $_smarty_tpl->tpl_vars['value']->value['content'];?>
</div>
</div>
<?php }} else { ?>
暂无评论！
<?php } ?>
</li>
</ul>
</div>
<?php if ($_smarty_tpl->getVariable('username')->value){?>
<form name="comment" action="<?php if ($_smarty_tpl->getVariable('page')->value['pid']){?><?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'comments_page','pid'=>$_smarty_tpl->getVariable('page')->value['pid']),$_smarty_tpl);?>
<?php }else{ ?><?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'comments_post','pid'=>$_smarty_tpl->getVariable('post')->value['pid'],'cid'=>$_smarty_tpl->getVariable('post')->value['cid']),$_smarty_tpl);?>
<?php }?>" method="post">
<textarea name="content" id="text" class="textarea"></textarea>
<button class="btn">评论</button>
</form><br><br>
<?php }else{ ?>
<div class="ui-faq-question">
<p>您需要 <a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'login'),$_smarty_tpl);?>
">登陆</a> 后才可以评论，如果您没有账号，可以 <a href="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['spUrl'][0][0]->__template_spUrl(array('c'=>'main','a'=>'register'),$_smarty_tpl);?>
">注册</a> 。</p>
</div>
<?php }?>