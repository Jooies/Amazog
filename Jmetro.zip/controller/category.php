<?php
class category extends spController{
    function index(){

    }
    
    function add(){
        // 添加标签
        $categoryObj = spClass("m_category");
        if($name = $this->spArgs("name")){
            $row = array("name"=>$name);
            $result = $categoryObj->spVerifier($row);
            if(false == $result){//access the verify
               if(true == $categoryObj->check_repeat($name)){//no repeat name
                    $categoryObj->create($row);
                    $this->success("添加成功!",spUrl("category","admin"));
                }else{
                    $this->error("添加失败,分类已经存在!",spUrl("category","add"));
                }
            }else{
                foreach($result as $item){
                    foreach($item as $msg){
                        $this->error($msg,spUrl("category","add"));
                    }
                }
            }
        }
        $this->category = $categoryObj->findall();
        $this->display("category/add.html");
    }
    
    function admin(){
        $categoryObj = spClass("m_category");
        $this->category = $categoryObj->spPager($this->spArgs('page', 1), 10)->findAll();
        $this->pager = $categoryObj->spPager()->getPager();
        $this->display("category/admin.html");
    }
    
    function modify(){
        //modify category function
        $cid = $this->spArgs("cid");
        $categoryObj = spClass("m_category");
        $conditions = array("cid"=>$cid);
        $this->category = $categoryObj->find($conditions);
        if($name = $this->spArgs("name")){
            $row = array("name"=>$name);
            $result = $categoryObj->spVerifier($row);
            if(false == $result){//access the verify
               if(true == $categoryObj->check_repeat($name)){//no repeat name
                    $categoryObj->update($conditions,$row);
                    $this->success("Modify Successfully!",spUrl("category","admin"));
                }else{                   
                    $this->error("Modify Faild,it exists!",spUrl("category","modify",array("cid"=>$cid)));
                }
            }else{
                foreach($result as $item){
                    foreach($item as $msg){                       
                        $this->error($msg,spUrl("category","modify",array("cid"=>$cid)));
                    }
                }
            }
        }  
        $this->display("category/modify.html");
        
    }
    
    function delete(){
        //delete category function
        $categoryObj = spClass("m_category");
        $cid = $this->spArgs("cid");
        $conditions = array("cid"=>$cid);
        if($categoryObj->delete($conditions)){
            $this->success("删除成功!",spUrl("category","admin"));
        }else{
            $this->error("删除失败!",spUrl("category","admin"));
        }
        
    }
}